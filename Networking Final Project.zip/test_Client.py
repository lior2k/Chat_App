from unittest import TestCase


class Test(TestCase):
    def test_checksum(self):
        self.fail()

    def test_recv_msg(self):
        self.fail()

    def test_send_msg(self):
        self.fail()

    def test_init_packets_dict(self):
        self.fail()

    def test_unsplit(self):
        self.fail()

    def test_write_to_file(self):
        self.fail()

    def test_download_file(self):
        self.fail()
